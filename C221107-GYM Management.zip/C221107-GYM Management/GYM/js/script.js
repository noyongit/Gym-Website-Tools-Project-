let searchForm = document.querySelector('.search-from');

document.querySelector('#search-btn').onclick = () =>
{
	searchForm.classList.toggle('active');
}


let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () =>
{
	shoppingCart.classList.toggle('active');
}